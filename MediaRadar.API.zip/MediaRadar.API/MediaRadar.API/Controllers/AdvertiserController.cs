﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Filters;
using MediaRadar.Domain.Common;


namespace MediaRadar.API.Controllers
{
    
    public class AdvertiserController : BaseMediaRadarAPIController
    {
        private readonly MediaRadar.Domain.Abstract.IMagazineRepository _magazineRepository;

        private Domain.Model.MediaRadarAPIAccess _token;
        public AdvertiserController()
        {
            this._token = new Domain.Model.MediaRadarAPIAccess() { HeaderKey = "Ocp-Apim-Subscription-Key", HeaderValue = "293d6276c7f44b9bbae21d85794656b5", url = "https://api-c.mediaradar.com/HiringAssessment/PublicationAdActivity?startDate=2011-01-01&endDate=2011-04-01" };
            this._magazineRepository = new MediaRadar.Domain.Concrete.MagazineRepository();// We can replace here by an IoC container, i.e. Unity     
        }
        [HttpGet]
        public ReturnModel ListMagazineByDefaultBrandName()
        {
            int i = 0;
            try
            {
                return new ReturnModel
                {
                    Msg = base.DEFAULT_CONFIRMATION_MESSAGE,
                    Success = true,
                    Results = this._magazineRepository.ListMagazineByDefaultBrandName(this._token)
                };
            }
            catch(Exception ex)
            {
                return new ReturnModel
                {
                    Msg = base.ERROR_MESSAGE,
                    Success = false,
                    Results = ex.ToString()
                };
            }
        }
        [HttpGet]
        public ReturnModel QualifiedMagzineSum()
        {
            try
            {
                return new ReturnModel
                {
                    Msg = base.DEFAULT_CONFIRMATION_MESSAGE,
                    Success = true,
                    Results = this._magazineRepository.QualifiedMagzineSum(this._token)
                };
            }
            catch (Exception ex)
            {
                return new ReturnModel
                {
                    Msg = base.ERROR_MESSAGE,
                    Success = false,
                    Results = ex.ToString()
                };
            }
        }


        [HttpGet]
        public ReturnModel Top5ProductCategoriesByEstSpendSum()
        {
            try
            {
                return new ReturnModel
                {
                    Msg = base.DEFAULT_CONFIRMATION_MESSAGE,
                    Success = true,
                    Results = this._magazineRepository.Top5ProductCategoriesByEstSpendSum(this._token)
                };
            }
            catch (Exception ex)
            {
                return new ReturnModel
                {
                    Msg = base.ERROR_MESSAGE,
                    Success = false,
                    Results = ex.ToString()
                };
            }
        }


        [HttpGet]
        public ReturnModel Top5ParentCompanies()
        {
            try
            {
                return new ReturnModel
                {
                    Msg = base.DEFAULT_CONFIRMATION_MESSAGE,
                    Success = true,
                    Results = this._magazineRepository.Top5ParentCompanies(this._token)
                };
            }
            catch (Exception ex)
            {
                return new ReturnModel
                {
                    Msg = base.ERROR_MESSAGE,
                    Success = false,
                    Results = ex.ToString()
                };
            }
        }
    }
}
