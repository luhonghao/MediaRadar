﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MediaRadar.API.Controllers
{
    public class BaseMediaRadarAPIController : ApiController
    {
        public readonly string DEFAULT_CONFIRMATION_MESSAGE = "OK";
        public readonly string ERROR_MESSAGE = "UNKNOWN ERROR ON THE SERVER";
    }
}
