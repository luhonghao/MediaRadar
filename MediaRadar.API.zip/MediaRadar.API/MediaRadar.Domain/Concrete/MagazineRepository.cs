﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediaRadar.Domain.Abstract;
using MediaRadar.Domain.Model;

namespace MediaRadar.Domain.Concrete
{
    public class MagazineRepository : IMagazineRepository
    {
        private void ListMagazineByDefaultBrandNameHelper(ref List<Magazine> originMagzineList)
        {
            originMagzineList.Sort((a, b) => a.BrandName.CompareTo(b.BrandName));
        }

        private IEnumerable<BrandSummary> QualifiedMagzineSumHelper(List<Magazine> originMagzineList, string targetCategory = "Toiletries & Cosmetics > Hair Care")
        {
            var qualified = originMagzineList.Where(x => x.AdPages >= 2 && (x.ProductCategory == targetCategory || x.ProductCategory.Contains(targetCategory))).ToList<Magazine>();
            var result = from m in qualified
                         group m by new { m.BrandName } into g
                         orderby g.Key.BrandName ascending
                         select new BrandSummary() { BrandName = g.Key.BrandName, TotalAdPages = g.Sum(m => m.AdPages) };


            return result.ToList<BrandSummary>();
        }

        private IEnumerable<CategorySummary> Top5ProductCategoriesByEstSpendSumHelper(List<Magazine> originMagzineList)
        {
            var summary = from m in originMagzineList
                          group m by new { m.ProductCategory } into g
                          select new CategorySummary() { CategoryName = g.Key.ProductCategory, TotalEstSpend = g.Sum(m => m.EstPrintSpend), TotalAdPages = g.Sum(m => m.AdPages) };

            var result = (from m in summary
                          orderby m.TotalAdPages descending, m.CategoryName ascending
                          select m).Take(5).ToList<CategorySummary>();

            return result;
        }

        private IEnumerable<MagazineSummary> Top5ParentCompaniesHelper(List<Magazine> originMagzineList)
        {
            var list = from m in originMagzineList
                       group m by new { m.ParentCompany } into g
                       select new MagazineSummary() { ParentCompany = g.Key.ParentCompany, TotalAdPages = g.Sum(m => m.AdPages), TotalEstSpent = g.Sum(m => m.EstPrintSpend) };

            var result = (from m in list
                          orderby m.TotalAdPages descending, m.TotalEstSpent descending, m.ParentCompany ascending
                          select m).Take(5).ToList<MagazineSummary>();
            return result;
        }

        public List<MediaRadar.Domain.Model.Magazine> ListMagazineByDefaultBrandName(MediaRadarAPIAccess token)
        {
            List<MediaRadar.Domain.Model.Magazine> mags = MediaRadar.Domain.Common.Utility.GetAdverstisement(token).ToList<Magazine>();
            this.ListMagazineByDefaultBrandNameHelper(ref mags);
            return mags;
        }

        public IEnumerable<BrandSummary> QualifiedMagzineSum(MediaRadarAPIAccess token)
        {
            List<MediaRadar.Domain.Model.Magazine> mags = MediaRadar.Domain.Common.Utility.GetAdverstisement(token).ToList<Magazine>();
            List<BrandSummary> result = QualifiedMagzineSumHelper(mags).ToList<BrandSummary>();
            return result;
        }

        public IEnumerable<CategorySummary> Top5ProductCategoriesByEstSpendSum(MediaRadarAPIAccess token)
        {
            List<MediaRadar.Domain.Model.Magazine> mags = MediaRadar.Domain.Common.Utility.GetAdverstisement(token).ToList<Magazine>();
            List<CategorySummary> result = Top5ProductCategoriesByEstSpendSumHelper(mags).ToList<CategorySummary>();
            return result;
        }

        public IEnumerable<MagazineSummary> Top5ParentCompanies(MediaRadarAPIAccess token)
        {
            List<MediaRadar.Domain.Model.Magazine> mags = MediaRadar.Domain.Common.Utility.GetAdverstisement(token).ToList<Magazine>();
            List<MagazineSummary> result = Top5ParentCompaniesHelper(mags).ToList<MagazineSummary>();
            return result;
        }
    }
}
