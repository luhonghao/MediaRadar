﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using MediaRadar.Domain.Model;

namespace MediaRadar.Domain.Common
{
    public class Utility
    {

        private static async Task<string> Download(MediaRadar.Domain.Model.MediaRadarAPIAccess token)
        {
            using (HttpClient client = new HttpClient())
            {
                //client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "293d6276c7f44b9bbae21d85794656b5");
                client.DefaultRequestHeaders.Add(token.HeaderKey, token.HeaderValue);
                //HttpResponseMessage response = await client.GetAsync("https://api-c.mediaradar.com/HiringAssessment/PublicationAdActivity?startDate=2011-01-01&endDate=2011-04-01");
                HttpResponseMessage response = await client.GetAsync(token.url);
                HttpContent content = response.Content;
                string result = await content.ReadAsStringAsync();

                return result;
            }
        }

        public static IEnumerable<MediaRadar.Domain.Model.Magazine> GetAdverstisement(MediaRadar.Domain.Model.MediaRadarAPIAccess token)
        {
            string jsonData = Task.Run( () => Utility.Download(token)).Result;
            List<MediaRadar.Domain.Model.Magazine> result = JsonConvert.DeserializeObject<List<Magazine>>(jsonData);
            return result;
        }
    }
}
