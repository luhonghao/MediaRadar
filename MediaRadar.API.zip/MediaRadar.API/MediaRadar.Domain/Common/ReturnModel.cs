﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Runtime.Serialization;

namespace MediaRadar.Domain.Common
{
    [DataContract]
    public struct ReturnModel
    {
        [DataMember(Name = "success")]
        public bool Success;
        [DataMember(Name = "msg")]
        public string Msg;
        [DataMember(Name = "results")]
        public dynamic Results;
    }
}
