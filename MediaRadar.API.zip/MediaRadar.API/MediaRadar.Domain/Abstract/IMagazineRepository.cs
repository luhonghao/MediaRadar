﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediaRadar.Domain.Model;


namespace MediaRadar.Domain.Abstract
{
    public interface IMagazineRepository
    {
        //void ListMagazineByDefaultBrandName(ref List<Magazine> originMagzineList);
        //IEnumerable<BrandSummary> QualifiedMagzineSum(List<Magazine> originMagzineList, string targetCategory = "Toiletries & Cosmetics > Hair Care");
        //IEnumerable<CategorySummary> Top5ProductCategoriesByEstSpendSum(List<Magazine> originMagzineList);
        //IEnumerable<MagazineSummary> Top5ParentCompanies(List<Magazine> originMagzineList);

        List<MediaRadar.Domain.Model.Magazine> ListMagazineByDefaultBrandName(MediaRadar.Domain.Model.MediaRadarAPIAccess token);
        IEnumerable<BrandSummary> QualifiedMagzineSum(MediaRadar.Domain.Model.MediaRadarAPIAccess token);
        IEnumerable<CategorySummary> Top5ProductCategoriesByEstSpendSum(MediaRadar.Domain.Model.MediaRadarAPIAccess token);
        IEnumerable<MagazineSummary> Top5ParentCompanies(MediaRadar.Domain.Model.MediaRadarAPIAccess token);

    }
}
