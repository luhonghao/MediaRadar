﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaRadar.Domain.Model
{
    public class MediaRadarAPIAccess
    {
        public string url { get; set; }

        public string HeaderKey { get; set; }
        public string HeaderValue { get; set; }

    }
}
