﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaRadar.Domain.Model
{
    public class BrandSummary
    {
        public double TotalAdPages { get; set; }
        public string BrandName { get; set; }
    }
}
