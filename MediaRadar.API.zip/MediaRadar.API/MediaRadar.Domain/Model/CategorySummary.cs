﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaRadar.Domain.Model
{
    public class CategorySummary
    {
        public string CategoryName { get; set; }
        public double TotalEstSpend { get; set; }
        public double TotalAdPages { get; set; }
    }
}
